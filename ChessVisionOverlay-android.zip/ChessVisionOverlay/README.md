# ChessVision Overlay (Android)

Floating, draggable, resizable ChessVision window that stays on top of other apps.

## Build

Open this folder in Android Studio (JDK 17), let Gradle sync, then Run on your phone
(or Build > Build APK(s) and install it). First launch: tap **Start overlay**, allow
"Display over other apps", and the overlay starts automatically when you come back.

## Using the window

| Do this | To |
|---|---|
| Drag the title bar | Move it (stays on screen, also after rotating) |
| Drag a **bottom corner** | Resize (left corner keeps the right edge fixed) |
| Drag the **bottom bar** | Change height only |
| Tap **⤢** | Cycle small / medium / large |
| Tap **—** (or tap the title when minimised) | Minimise to a title bar that shows the top move + eval. The engine keeps running |
| Tap a text field (FEN, ELO) | Keyboard opens by itself; Back closes it. **⌨** is a manual toggle |
| **−** / **+** under the board, or "Board size" in settings | Make the board smaller / larger inside the window |
| **✕** or the notification's Stop | Close |

Size and position are remembered. **Reset size & position** is on the main screen.

## How the scaling works

`chessvision.html?overlay=1` (also auto-detected via the `CVNative` bridge) switches the page into a
compact, always-dark layout and scales everything to the window width, so a smaller window gives a smaller
board and a bigger window a bigger one. The same file still works in a normal browser.

The app is `app/src/main/assets/chessvision.html` - edit it to change the board.

## Style: Engine / Human / Fischer

Settings > Style. **Human** prefers natural moves (develop, castle, recapture, check) and its mistakes scale with
the ELO setting (seeded per position, so results don't flicker). **Fischer** adds his repertoire as an opening book
(Ruy Lopez, Fischer Attack, Najdorf, King's Indian, Grunfeld, Nimzo...), central pawns, keeping the bishop pair,
simplifying when ahead, avoiding early draws, and endgame technique (king activity, 7th-rank rooks, passed pawns).
Book moves are only used when the engine agrees they are sound. Use ELO 2700+ for full strength.

## Added in this version

- **Drag to move** pieces (tap-to-move still works). Pieces glide when you tap-move; the engine pauses while you drag.
- **Brilliant move marker (!!)**: flags a sacrifice that a deeper check still rates best. Shown on candidates, on the board square, and added to the PGN. The engine is small, so it only catches tactics within its search depth.
- **Board fits the window height** as well as width, and re-fits when you resize. Window can scale up to 1.8x.
- Build on GitHub: `.github/workflows/build.yml` produces the debug APK as an Actions artifact.
