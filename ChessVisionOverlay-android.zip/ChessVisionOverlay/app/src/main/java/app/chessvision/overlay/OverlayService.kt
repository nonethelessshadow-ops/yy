package app.chessvision.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot

/**
 * Floating ChessVision window.
 *
 *  - Drag by the title bar.
 *  - Resize by the bottom-left / bottom-right corners (or the bottom bar for height only).
 *  - The page (chessvision.html?overlay=1) rescales itself to the window width, so a smaller
 *    window means a smaller board. Size and position are remembered between launches.
 *  - Minimised, the title bar shows the current top move + eval and the engine keeps running.
 */
class OverlayService : Service() {

    companion object {
        @Volatile var running = false
        const val ACTION_STOP = "STOP"
        const val ACTION_RESET = "RESET"
        const val PREFS = "overlay"

        private const val PAGE_URL = "file:///android_asset/chessvision.html?overlay=1"
        private val BG = 0xFF121214.toInt()
        private val BAR = 0xFF24242A.toInt()
        private val GREEN = 0xFF10B981.toInt()

        // all in dp
        private const val HEADER = 38
        private const val FOOTER = 26
        private const val MIN_W = 200
        private const val MIN_H = 220
        private const val MAX_W = 520          // keeps the page in its compact layout
        private const val MINI_W = 220
        private const val DEF_W = 300
        private const val DEF_H = 430
        private const val DEF_X = 8
        private const val DEF_Y = 72
        private val PRESETS = listOf(240, 300, 380)   // widths; height follows 1.43 x
    }

    private val ui = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var rootView: View? = null
    private var webView: WebView? = null
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var prefs: SharedPreferences

    private lateinit var title: TextView
    private lateinit var kbBtn: TextView
    private lateinit var sizeBtn: TextView
    private lateinit var miniBtn: TextView
    private lateinit var body: FrameLayout
    private lateinit var footer: LinearLayout

    private var mini = false
    private var kb = false
    private var topText = ""
    private var fullW = 0
    private var fullH = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_RESET -> { if (rootView != null) resetBounds(); return START_NOT_STICKY }
        }
        val n = notification()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        if (rootView == null) show()
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("overlay", "Overlay", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).apply { action = ACTION_STOP }, PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "overlay")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("ChessVision overlay is running")
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_delete, "Stop", stop)
            .build()
    }

    // ---------------------------------------------------------------- helpers

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** Like coerceIn, but never throws when the screen is smaller than the minimum. */
    private fun clampInt(v: Int, lo: Int, hi: Int) = maxOf(lo, minOf(v, hi))

    @Suppress("DEPRECATION")
    private fun screen(): Pair<Int, Int> {
        val m = wm ?: return 1080 to 1920
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = m.maximumWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = DisplayMetrics()
            m.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    }

    private fun currentHeight() = if (mini) dp(HEADER) else lp.height

    /** Keep the window fully on screen (re-read on every call, so rotation is handled). */
    private fun clampPos() {
        val (sw, sh) = screen()
        lp.x = clampInt(lp.x, 0, sw - lp.width)
        lp.y = clampInt(lp.y, 0, sh - currentHeight())
    }

    private fun clampSize() {
        val (sw, sh) = screen()
        if (!mini) {
            lp.width = clampInt(lp.width, minOf(dp(MIN_W), sw), minOf(dp(MAX_W), sw))
            lp.height = clampInt(lp.height, minOf(dp(MIN_H), sh), sh)
        }
        clampPos()
    }

    private fun applyLayout() {
        val r = rootView ?: return
        try { wm?.updateViewLayout(r, lp) } catch (_: IllegalArgumentException) { /* already removed */ }
    }

    private fun saveBounds() {
        if (!::lp.isInitialized) return
        val d = resources.displayMetrics.density
        prefs.edit().apply {
            putInt("x", (lp.x / d).toInt()); putInt("y", (lp.y / d).toInt())
            if (!mini) { putInt("w", (lp.width / d).toInt()); putInt("h", (lp.height / d).toInt()) }
        }.apply()
    }

    private fun resetBounds() {
        prefs.edit().clear().apply()
        if (mini) setMini(false)
        lp.width = dp(DEF_W); lp.height = dp(DEF_H); lp.x = dp(DEF_X); lp.y = dp(DEF_Y)
        clampSize(); applyLayout(); saveBounds()
    }

    private fun refreshTitle() {
        title.text = if (mini) "  ♟ " + topText.ifBlank { "ChessVision" } else "  ♟ ChessVision"
    }

    // keyboard: the window is non-focusable (so the app underneath keeps working) until a text field needs typing
    private fun setKeyboard(on: Boolean) {
        if (kb == on) return
        kb = on
        val noFocus = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        lp.flags = if (on) lp.flags and noFocus.inv() else lp.flags or noFocus
        applyLayout()
        kbBtn.setTextColor(if (on) GREEN else Color.WHITE)
        val web = webView ?: return
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        if (on) {
            web.requestFocus()
            web.postDelayed({ if (kb) imm.showSoftInput(web, InputMethodManager.SHOW_IMPLICIT) }, 150)
        } else {
            imm.hideSoftInputFromWindow(web.windowToken, 0)
        }
    }

    private fun setMini(m: Boolean) {
        if (m == mini) return
        if (m) {
            setKeyboard(false)
            saveBounds()
            fullW = lp.width; fullH = lp.height
        }
        mini = m
        // The WebView keeps a 1px strip while minimised: a hidden WebView throttles its timers
        // and the engine would crawl. At 1px it stays "visible" and keeps analysing.
        (body.layoutParams as LinearLayout.LayoutParams).apply { height = if (m) 1 else 0; weight = if (m) 0f else 1f }
        body.requestLayout()
        footer.visibility = if (m) View.GONE else View.VISIBLE
        kbBtn.visibility = if (m) View.GONE else View.VISIBLE
        sizeBtn.visibility = if (m) View.GONE else View.VISIBLE
        miniBtn.text = if (m) "▢" else "—"
        if (m) { lp.width = dp(MINI_W); lp.height = ViewGroup.LayoutParams.WRAP_CONTENT }
        else { lp.width = fullW; lp.height = fullH }
        refreshTitle()
        clampSize(); applyLayout(); saveBounds()
    }

    private fun cycleSize() {
        val next = PRESETS.firstOrNull { dp(it) > lp.width + dp(6) } ?: PRESETS[0]
        lp.width = dp(next); lp.height = (dp(next) * 1.43f).toInt()
        clampSize(); applyLayout(); saveBounds()
    }

    // ---------------------------------------------------------------- JS bridge

    inner class Bridge {
        @JavascriptInterface fun top(t: String) { ui.post { topText = t; if (mini) refreshTitle() } }
        @JavascriptInterface fun kb(on: Boolean) { ui.post { setKeyboard(on) } }
        @JavascriptInterface fun copy(t: String) {
            ui.post {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("ChessVision", t))
            }
        }
    }

    // ---------------------------------------------------------------- window

    private fun show() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow \"Display over other apps\" first", Toast.LENGTH_LONG).show()
            stopSelf(); return
        }
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = manager
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val (sw, sh) = screen()
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        val wc = ViewGroup.LayoutParams.WRAP_CONTENT

        lp = WindowManager.LayoutParams(
            clampInt(dp(prefs.getInt("w", DEF_W)), minOf(dp(MIN_W), sw), minOf(dp(MAX_W), sw)),
            clampInt(dp(prefs.getInt("h", DEF_H)), minOf(dp(MIN_H), sh), sh),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(prefs.getInt("x", DEF_X)); y = dp(prefs.getInt("y", DEF_Y))
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }
        clampPos()

        // ---- web content
        val web = WebView(this).apply {
            setBackgroundColor(BG)
            overScrollMode = View.OVER_SCROLL_NEVER
            with(settings) {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false          // file:///android_asset still loads
                allowContentAccess = false
                textZoom = 100                   // ignore the system font size: the page scales itself
                setSupportZoom(false)
                setBuiltInZoomControls(false)
                setDisplayZoomControls(false)
            }
            addJavascriptInterface(Bridge(), "CVNative")
            webViewClient = object : WebViewClient() {
                // Never navigate away from our own page (the bridge must not be reachable by other sites)
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest) =
                    !request.url.toString().startsWith("file:///android_asset/")
                override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                    ui.post { stopSelf() }
                    return true
                }
            }
            loadUrl(PAGE_URL)
        }
        webView = web
        body = FrameLayout(this).apply { addView(web, FrameLayout.LayoutParams(mp, mp)) }

        // ---- header (drag + buttons)
        title = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER_VERTICAL
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(BAR)
            addView(title, LinearLayout.LayoutParams(0, mp, 1f))
        }
        fun btn(t: String, desc: String, onClick: () -> Unit) = TextView(this).apply {
            text = t; contentDescription = desc
            setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            minWidth = dp(40)
            setOnClickListener { onClick() }
        }
        kbBtn = btn("⌨", "Toggle keyboard") { setKeyboard(!kb) }
        sizeBtn = btn("⤢", "Change size") { cycleSize() }
        miniBtn = btn("—", "Minimise") { setMini(!mini) }
        val closeBtn = btn("✕", "Close") { stopSelf() }
        for (b in listOf(kbBtn, sizeBtn, miniBtn, closeBtn)) header.addView(b, LinearLayout.LayoutParams(wc, mp))
        refreshTitle()

        // ---- footer: resize handles
        fun grip(t: String, desc: String) = TextView(this).apply {
            text = t; contentDescription = desc
            setTextColor(0xB3FFFFFF.toInt()); textSize = 18f; gravity = Gravity.CENTER
        }
        val gripL = grip("◣", "Resize from left")
        val gripR = grip("◢", "Resize from right")
        val gripM = FrameLayout(this).apply {
            contentDescription = "Resize height"
            addView(View(context).apply {
                background = GradientDrawable().apply { setColor(0x66FFFFFF); cornerRadius = dp(2).toFloat() }
            }, FrameLayout.LayoutParams(dp(44), dp(4), Gravity.CENTER))
        }
        footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(BAR)
            addView(gripL, LinearLayout.LayoutParams(dp(56), mp))
            addView(gripM, LinearLayout.LayoutParams(0, mp, 1f))
            addView(gripR, LinearLayout.LayoutParams(dp(56), mp))
        }

        // ---- root
        val root = object : LinearLayout(this) {
            // Back closes the keyboard (only reaches us while the window is focusable)
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (kb && event.keyCode == KeyEvent.KEYCODE_BACK) {
                    if (event.action == KeyEvent.ACTION_UP) setKeyboard(false)
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }.apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(BG); cornerRadius = dp(14).toFloat(); setStroke(dp(1), GREEN)
            }
            clipToOutline = true
            addView(header, LinearLayout.LayoutParams(mp, dp(HEADER)))
            addView(body, LinearLayout.LayoutParams(mp, 0, 1f))
            addView(footer, LinearLayout.LayoutParams(mp, dp(FOOTER)))
        }
        rootView = root

        attachDrag(header)
        attachResize(gripL, -1)
        attachResize(gripR, 1)
        attachResize(gripM, 0)

        try {
            manager.addView(root, lp)
            running = true
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't show the overlay: ${e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            rootView = null
            stopSelf()
        }
    }

    /** Drag by the header. A tap (no movement) on the minimised header restores the window. */
    private fun attachDrag(header: View) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        header.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx; val dy = e.rawY - ty
                    if (moved || hypot(dx, dy) > slop) {
                        moved = true
                        lp.x = (sx + dx).toInt(); lp.y = (sy + dy).toInt()
                        clampPos(); applyLayout()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) saveBounds() else if (mini) setMini(false)
                }
            }
            true
        }
    }

    /** edge: -1 = bottom-left corner, +1 = bottom-right corner, 0 = bottom bar (height only). */
    private fun attachResize(handle: View, edge: Int) {
        var sw = 0; var sh = 0; var sx = 0; var gx = 0f; var gy = 0f
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sw = lp.width; sh = lp.height; sx = lp.x; gx = e.rawX; gy = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    val (scrW, scrH) = screen()
                    val dx = (e.rawX - gx).toInt(); val dy = (e.rawY - gy).toInt()
                    val minW = minOf(dp(MIN_W), scrW); val maxW = minOf(dp(MAX_W), scrW)
                    when {
                        edge > 0 -> lp.width = clampInt(sw + dx, minW, minOf(maxW, scrW - lp.x))
                        edge < 0 -> {
                            val right = sx + sw                       // keep the right edge fixed
                            lp.width = clampInt(sw - dx, minW, minOf(maxW, right))
                            lp.x = right - lp.width
                        }
                    }
                    lp.height = clampInt(sh + dy, minOf(dp(MIN_H), scrH), scrH - lp.y)
                    applyLayout()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> saveBounds()
            }
            true
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // rotation / fold / display-size change: pull the window back inside the new screen bounds
        ui.postDelayed({ if (rootView != null) { clampSize(); applyLayout() } }, 200)
    }

    override fun onDestroy() {
        running = false
        ui.removeCallbacksAndMessages(null)
        saveBounds()
        rootView?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        webView?.let {
            it.removeJavascriptInterface("CVNative")
            (it.parent as? ViewGroup)?.removeView(it)
            it.stopLoading()
            it.destroy()
        }
        rootView = null; webView = null
        super.onDestroy()
    }
}
