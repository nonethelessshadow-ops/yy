package app.chessvision.overlay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private var startAfterPermission = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (24 * d).toInt()
        val wc = ViewGroup.LayoutParams.WRAP_CONTENT
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        fun gap(px: Int) = LinearLayout.LayoutParams(mp, wc).apply { topMargin = px }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply { text = "ChessVision Overlay"; textSize = 24f })
        root.addView(TextView(this).apply {
            text = "Floats a small analysis board over other apps. Tap Start, allow \"Display over other apps\" if asked, then open your chess app or video."
            setPadding(0, pad / 2, 0, pad / 2)
        })
        status = TextView(this).apply { textSize = 14f }
        root.addView(status, gap(0))
        root.addView(Button(this).apply { text = "Start overlay"; setOnClickListener { startOverlay() } }, gap(pad / 2))
        root.addView(Button(this).apply {
            text = "Stop overlay"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)); refresh() }
        }, gap(0))
        root.addView(Button(this).apply { text = "Reset size & position"; setOnClickListener { resetBounds() } }, gap(0))
        root.addView(TextView(this).apply {
            text = "In the window: drag the title bar to move it; drag the bottom corners to resize; ⤢ cycles small / medium / large; — minimises (the title bar then shows the top move)."
            textSize = 13f
            setPadding(0, pad, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        // Came back from the "Display over other apps" screen: carry on and start.
        if (startAfterPermission && Settings.canDrawOverlays(this)) {
            startAfterPermission = false
            startOverlay()
        }
        refresh()
    }

    private fun refresh() {
        status.text = when {
            OverlayService.running -> "Overlay is running."
            !Settings.canDrawOverlays(this) -> "Needs the \"Display over other apps\" permission."
            else -> "Ready."
        }
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startAfterPermission = true
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        startForegroundService(Intent(this, OverlayService::class.java))
        moveTaskToBack(true)
    }

    private fun resetBounds() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).apply { action = OverlayService.ACTION_RESET })
        } else {
            getSharedPreferences(OverlayService.PREFS, MODE_PRIVATE).edit().clear().apply()
        }
        status.text = "Size and position reset."
    }
}
